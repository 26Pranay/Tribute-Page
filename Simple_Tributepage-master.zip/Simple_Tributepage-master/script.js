function displayMessage() {
    alert("This is a tribute to Sundar Pichai.");
}